create database Movie_Shopping;

use Movie_Shopping;

create table Customer (
id char(8) not null primary key, 
firstName varchar(20) DEFAULT NULL,
lastName varchar(20) DEFAULT NULL,
phone char(12) DEFAULT NULL,
address varchar(30) DEFAULT NULL,
email varchar(20) DEFAULT NULL,
userName varchar(20) DEFAULT NULL,
password varchar(20) DEFAULT NULL
)ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

insert into Customer Values
("12345675","John","Smith","514-444-5454","235 Sherbrook West","js12@yahoo.com","IPD17john","12john23smith"),
("21345678","Mark","Fransois","514-546-7774","2600 Bon Mary","mark200@gmail.com","IPD17M1234","mark2600fran");
UNLOCK table;


create table Movie (
movieId varchar(5) not null primary key,
title varchar(60) DEFAULT NULL,
genre varchar (20) DEFAULT NULL,
director varchar(40) DEFAULT NULL,
language varchar(15) DEFAULT NULL,
releaseYear char(4) DEFAULT NULL,
image blob DEFAULT NULL
)ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

insert into Movie(movieId, title, genre, director, language, releaseYear)  Values
("Co1", "Modern Times", "Comedy", "Charlie Chaplin", "English", "1936"),
("Co2","Abominable","Comedy", "Jill Culton", "English", "2019"),
("Do1","Everybody's Everything","Documentary", "Sebastian Jones", "English", "2019"),
("Do2","Planet Earth II","Documentary", " David Attenborough", "Spanish", "2016"),
("Ac1","The Matrix","Action", "Lilly Wachowski", "English", "1999"),
("Ac2","Face/Off","Action", "John Woo", "English", "1997"),
("Dr1","Gladiator","Drama", "Ridley Scott", "English", "2000"),
("Dr2","A Beautiful Mind","Drama", "Ron Howard", "English", "2001"),
("Cr1","Pulp Fiction","Crime", "Quentin Tarantino", "English", "1994"),
("Cr2","The Connection","Crime", "Cédric Jimenez", "French", "2015");
UNLOCK table;

select * from movie;

drop table movie;
